const fs = require("node:fs");

fs.writeFileSync("hello.txt", "Tolu: 'How are you?'");
fs.appendFileSync("hello.txt", "Seyi: 'I am fine too and you?'");

const note = function () {
  return "Your Note is doing fine...";
};

module.exports = intro;
